import os
import requests
import shutil
import time
import re
from multiprocessing.dummy import Pool as ThreadPool
from math import pow
import argparse


class DownloaderApp:
    """
    Load images from the repository 'https://esper.biomedical.hosting/login/'
    """
    def __init__(self, approximation, slide_name, directory, num_threads=4, user_id='ananya', password='alcyone'):
        self.approximation = approximation
        self.slide_name = slide_name
        self.user_id = user_id
        self.password = password
        self.work_directory = directory
        self.save_path = os.path.join(directory, slide_name)
        self.max_approximation = 17
        self.num_threads = num_threads
        self.url = 'https://esper.biomedical.hosting/login/'
        self.session = None

    def download_image(self, img_url):
        split_url = re.split('/', img_url)
        name_img = split_url[len(split_url) - 1]
        response = self.session.get(img_url, stream=True)
        name = os.path.join(self.save_path, 'img' + name_img)
        with open(name, 'wb') as out_file:
            shutil.copyfileobj(response.raw, out_file)
        del response

    def download_images(self):
        if not os.path.exists(self.save_path):
            os.makedirs(self.save_path)

        self.session = requests.session()

        login_data = {
            'user_id': self.user_id,
            'pw': self.password,
            'next_url': 'https://esper.biomedical.hosting'
        }
        r = self.session.post(self.url, data=login_data)
        response = self.session.get('https://esper.biomedical.hosting/' + self.slide_name + '.scn.dzi')
        splited_text = re.split('"', response.text)
        del response
        max_x = round(int(splited_text[11]) / 256)
        max_y = round(int(splited_text[9]) / 256)

        coef_for_max = (self.max_approximation - self.approximation) * 2
        if coef_for_max != 0:
            max_x = round(max_x / coef_for_max)
            max_y = round(max_y / coef_for_max)

        image_urls = []
        for i in range(max_x):
            for j in range(max_y):
                image_urls.append('https://esper.biomedical.hosting/' + self.slide_name + '.scn_files/' + str(
                    self.approximation) + '/' + str(i) + '_' + str(j) + '.jpeg')

        if r.status_code == requests.codes.ok:
            # print('connected')
            pool = ThreadPool(self.num_threads)
            pool.map(self.download_image, image_urls)
            pool.close()
            pool.join()
            # print('complete')
        else:
            print('ERROR' + str(r.status_code))

    def approx_img(self, name_appx_img):
        self.save_path = os.path.join(self.work_directory, name_appx_img)
        x_y = re.split('_', re.search('\d+_\d+', name_appx_img)[0])
        x = int(x_y[0])
        y = int(x_y[1])

        if not os.path.exists(self.save_path):
            os.makedirs(self.save_path)

        coef = self.max_approximation - self.approximation
        coef = int(pow(2, coef))
        new_images_urls = []
        for i in range(x * coef, (x * coef) + coef):
            for j in range(y * coef, (y * coef) + coef):
                new_images_urls.append('https://esper.biomedical.hosting/' + self.slide_name + '.scn_files/' +
                                       str(self.max_approximation) + '/' + str(i) + '_' + str(j) + '.jpeg')

        self.session = requests.session()
        login_data = {
            'user_id': self.user_id,
            'pw': self.password,
            'next_url': 'https://esper.biomedical.hosting'
        }
        r = self.session.post(self.url, data=login_data)
        if r.status_code == requests.codes.ok:
            pool = ThreadPool(self.num_threads)
            pool.map(self.download_image, new_images_urls)
            pool.close()
            pool.join()
        else:
            print('ERROR' + str(r.status_code))


def main():
    parser = argparse.ArgumentParser(description='crawler utility')
    parser.add_argument('--approximation', type=int, default=15,
                        help='scale number')
    parser.add_argument('--slide_name', type=str,
                        help='path to img')
    parser.add_argument('--directory', type=str,
                        help='save_path')
    parser.add_argument('--num_threads', type=int, default=4,
                        help='number of threads')
    parser.add_argument('--userid', type=str, default='ananya',
                        help='hosting user id')
    parser.add_argument('--psw', type=str, default='alcyone',
                        help='hosting password')
    parser.add_argument('--download_full_img', action='store_true', default=False,
                        help='download a full image')
    parser.add_argument('--download_piece_img', action='store_true', default=False,
                        help='download a piece of image')
    parser.add_argument('--pic_names', type=str,
                        help='the image name is in the format X_X through a space')

    args = parser.parse_args()
    crawler = DownloaderApp(args.approximation, args.slide_name, args.directory, args.num_threads,
                      args.userid, args.psw)
    if args.download_full_img:
        crawler.download_images()
    if args.download_piece_img:
        for img_name in re.split(' ', args.pic_names):
            crawler.approx_img(img_name)


if __name__ == '__main__':
    main()
